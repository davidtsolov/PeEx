import json
import boto3
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

s3 = boto3.client('s3')

def lambda_handler(event, context):
    try:
        records = event.get("Records", [])
        if not records:
            logger.error("No records found in event")
            return {"error": "No records found in event"}

        s3_record = records[0]
        bucket_name = s3_record["s3"]["bucket"]["name"]
        file_key = s3_record["s3"]["object"]["key"] 

        logger.info(f"New file uploaded: {file_key} in bucket: {bucket_name}")
        response = s3.get_object(Bucket=bucket_name, Key=file_key)
        logger.info(f"Downloaded {file_key} from bucket {bucket_name}")
        json_content = response['Body'].read().decode('utf-8')
        logger.info(f"JSON content: {json_content}")
        data = json.loads(json_content)
        logger.info(f"JSON data: {data}")

        target_key = "name"
        if target_key in data:
            logger.info(f"Key '{target_key}' found in JSON file with value of '{data[target_key]}'.")
            return {"value": data[target_key]}
        else:
            logger.warning(f"Key '{target_key}' not found in JSON file.")
            return {"message": f"Key '{target_key}' is missing"}
    
    except Exception as e:
        logger.error(f"Error processing file: {str(e)}")
        return {"error": str(e)}